###
###

.pkgname <- "BSgenome.Msmeg.vumc.mc2155"

.seqnames <- paste(c("NC_008596.1"), sep="")

.circ_seqs <- NULL

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Mycobacterium smegmatis mc2155",
        common_name="Msmeg",
        provider="James Gallant",
        provider_version="mc2155.2020-09-27",
        release_date="2020-09-27",
        release_name="vumc James Gallant mc2155",
        source_url="-- information not available --",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Msmeg"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

