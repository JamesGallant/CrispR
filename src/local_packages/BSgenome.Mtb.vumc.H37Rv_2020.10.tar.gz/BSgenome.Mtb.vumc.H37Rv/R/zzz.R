###
###

.pkgname <- "BSgenome.Mtb.vumc.H37Rv"

.seqnames <- paste(c("NC_000962.3"), sep="")

.circ_seqs <- NULL

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Mycobacterium tuberculosis H37Rv",
        common_name="Mtb",
        provider="James Gallant",
        provider_version="H37Rv.2020-10-14",
        release_date="2020-10-14",
        release_name="vumc James Gallant H37Rv",
        source_url="-- information not available --",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Mtb"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

