###
###

.pkgname <- "BSgenome.Mtb.vumc.H37Rv"

.seqnames <- "NC_000962.3"

.circ_seqs <- character(0)

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Mycobacterium tuberculosis H37Rv",
        common_name="Mtb",
        genome="placeholder",
        provider="NCBI",
        release_date="2022-06-18",
        source_url="www.example.com",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Mtb"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

