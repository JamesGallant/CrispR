###
###

.pkgname <- "BSgenome.Mtuberculosis.VUmc.H37Rv"

.seqnames <- "NC_000962.3"

.circ_seqs <- NULL

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Mycobacterium tuberculosis H37Rv",
        common_name="Mtb",
        provider="VUmc",
        provider_version="H37Rv",
        release_date="2018-06-05",
        release_name="VUmc James Gallant H37Rv",
        source_url="https://mycobrowser.epfl.ch/releases/3/get_file?dir=fasta&file=Mycobacterium_tuberculosis_H37Rv.fasta",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Mtuberculosis"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

